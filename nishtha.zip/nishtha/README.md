# Hello world app for platformOS

## Usage

## npm tasks
* `npm start` - starts syncing to "dev" environment (make sure you have one added via pos-cli) and starts watching changes in assets to automatically sync them
* `npm run build` - build assets in production mode, minified, unused CSS classes purged
* `npm run build:dev` - build assets in development mode, unminified (full TailwindCSS included)
