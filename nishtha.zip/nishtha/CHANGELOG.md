7 February 2020 - Updated [TailwindCSS to 1.2.0](https://github.com/tailwindcss/tailwindcss/releases/tag/v1.2.0)

23 January 2020 - [Windows support](https://github.com/pavelloz/webpack-tailwindcss-purgecss/commit/83391b03abeb64e9e1c9e4ccc8bf118fe84c788d)

* Add macos and windows to CI
* Remove Node 8 from CI
* Add cross-env and del-cli to fix windows builds
